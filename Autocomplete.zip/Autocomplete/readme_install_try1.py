try:
    import readline
    readline  # make pyflakes happy, readline makes interactive mode keep history
except ImportError:
    # no readline on Windows
    print("passing");
    pass

print("passed");

