import csv

def suggestions_trends(query):
    if "how to" in query:
        with open("How_To.txt") as file1:
            reader = csv.reader(file1, skipinitialspace=True)
            how_to_list = [[int(no), word, int(freq)] for no, word, freq in reader]

        for index_i in (range(0, 499)):
            if query in how_to_list[index_i][1]:
                print("\nString " + how_to_list[i][1] + " found.")

        file1.close()

    else:
        with open("Trends.txt") as file1:
            reader = csv.reader(file1, skipinitialspace=True)
            trends_list = [[int(no), word, int(freq)] for no, word, freq in reader]

        for index_i in (range(0, 499)):
            if query in trends_list[index_i][1]:
                print("\nString " + trends_list[i][1] + " found.")

        file1.close()

def suggestions_personal(user_name,query):
    with open(user_name+".txt") as file1:
        reader = csv.reader(file1, skipinitialspace=True)
        user_name_list = [[word] for word in reader]

    for index_i in user_name_list:
        if query in user_name_list[index_i]:
            print("\nString " + user_name_list[index_i] + " found.")

    file1.close()

def suggestions_topics(user_name, query):
    with open(user_name+"_Topics.txt") as file1:
        reader = csv.reader(file1, skipinitialspace=True)
        user_topics_list = [[int(no), word] for no, word in reader]

    for index_i in user_topics_list: #[index_i][0]:
        with open(user_topics_list[index_i][1] + ".txt") as file2:
            reader = csv.reader(file2, skipinitialspace=True)
            current_topic_list = [[int(no), word, int(freq)] for no, word, freq in reader]
            file2.close()

        for index_j in current_topic_list[index_j][0]:
            if query in current_topic_list[index_j][1]:
                print('\n'+query+" in ")
                print(user_topics_list[index_i][1])

    file1.close()