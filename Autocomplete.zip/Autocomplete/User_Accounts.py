import pickle
import json

class User:
    user_count = 0

    def __init__(self):
        self.name = input("\nEnter name of user : ")
        self.password = input("\nEnter password for " + self.name + " : ")
        User.user_count+=1
        self.Sno = User.user_count
        file1 = open("User_Data", "ab+")
        json.dump(self,file1)
        #pickle.dump(self, open("User_Data", "ab+"))
        #me = pickle.load(open("User_Data", "rb+"))
        me.display()

    def display(self):
        print("\nPassword for user no "+" "+self.name+" is "+self.password)

    def read_file(self):
        with open("User_Data", "rb") as binary_file:
            # Read the whole file at once
            #data = binary_file.read()
            #data = " ".join(str(x) for x in data)
            #data = "".join(map(chr, data))
            #print(str(data))
            x = json.load(file1)
            print(x)

#user1 = User(bytearray("Sakshi",'utf-8'),bytearray("Sakshi",'utf-8'))
file1 = open("User_Data","wb+")
file1.close()
my = User()
my.read_file()