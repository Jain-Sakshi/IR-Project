import urllib.parse
import urllib.request
import json

url = "https://developers.google.com/custom-search/"

query = input("What do you want to search for ? >> ")

query = urllib.parse.urlencode( {'q' : query } )

response = urllib.request.urlopen (url + query ).read()
print(response)
#data = json.loads (response )

results = data [ 'responseData' ] [ 'results' ]

for result in results:
    title = result['title']
    url = result['url']
    print ( title + '; ' + url )